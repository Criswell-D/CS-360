package com.example.myapplication_dc;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private EditText etDate, etWeight, etTargetWeight;
    private Button btnLogin, btnCreateUser, btnAdd, btnView;
    private ListView lvWeightRecords;

    private Button btnAddUser, btnGetUser;

    private UserData userData;
    private ArrayList<String> weightRecords;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        etUsername = findViewById(R.id.editTextUsername);
        etPassword = findViewById(R.id.editTextTextPassword);
        btnLogin = findViewById(R.id.buttonLogin);
        btnCreateUser = findViewById(R.id.buttonCreateUser);
        etDate = findViewById(R.id.et_date);
        etWeight = findViewById(R.id.et_weight);
        etTargetWeight = findViewById(R.id.et_target_weight);
        btnAdd = findViewById(R.id.btn_add);
        btnView = findViewById(R.id.btn_view);
        lvWeightRecords = findViewById(R.id.lv_weight_records);

        // Initialize database helper
        userData = new UserData(this);

        // Initialize the weight records ArrayList and adapter
        weightRecords = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightRecords);
        lvWeightRecords.setAdapter(adapter);

        // User Login functionality
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                if (userData.validateUser(username, password)) {
                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    // Load weight tracking screen or functionality
                } else {
                    Toast.makeText(MainActivity.this, "Invalid login", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // User registration functionality
        btnCreateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                userData.addUser(username, password);
                Toast.makeText(MainActivity.this, "User created", Toast.LENGTH_SHORT).show();
            }
        });

        // Add weight record to the database
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightRecord();
            }
        });

        // View all weight records from the database
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWeightRecords();
            }
        });

        // Handle ListView item click for update and delete
        lvWeightRecords.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String record = weightRecords.get(position);
                int recordId = Integer.parseInt(record.split(",")[0].split(":")[1].trim());

                // Show update/delete dialog
                showUpdateDeleteDialog(recordId);
            }
        });
    }

    private void addWeightRecord() {
        String date = etDate.getText().toString();
        float weight = Float.parseFloat(etWeight.getText().toString());
        float targetWeight = Float.parseFloat(etTargetWeight.getText().toString());

        boolean isInserted = userData.addWeightRecord(date, weight, targetWeight);
        if (isInserted) {
            Toast.makeText(MainActivity.this, "Record added successfully", Toast.LENGTH_SHORT).show();
            loadWeightRecords(); // Refresh records list
        } else {
            Toast.makeText(MainActivity.this, "Failed to add record", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadWeightRecords() {
        Cursor cursor = userData.getAllRecords();
        weightRecords.clear();

        if (cursor.getCount() == 0) {
            Toast.makeText(MainActivity.this, "No records found", Toast.LENGTH_SHORT).show();
            return;
        }

        while (cursor.moveToNext()) {
            String record = "ID: " + cursor.getInt(0) +
                    ", Date: " + cursor.getString(1) +
                    ", Weight: " + cursor.getFloat(2) +
                    ", Target Weight: " + cursor.getFloat(3);
            weightRecords.add(record);
        }

        adapter.notifyDataSetChanged();
    }

    private void showUpdateDeleteDialog(final int recordId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Choose an option");

        builder.setItems(new CharSequence[]{"Update", "Delete"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    showUpdateDialog(recordId);
                } else {
                    deleteWeightRecord(recordId);
                }
            }
        });

        builder.show();
    }

    private void showUpdateDialog(final int recordId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Update Record");

        View updateView = getLayoutInflater().inflate(R.layout.dialog_update_weight, null);
        final EditText etUpdateDate = updateView.findViewById(R.id.et_update_date);
        final EditText etUpdateWeight = updateView.findViewById(R.id.et_update_weight);
        final EditText etUpdateTargetWeight = updateView.findViewById(R.id.et_update_target_weight);

        builder.setView(updateView);

        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String date = etUpdateDate.getText().toString();
                float weight = Float.parseFloat(etUpdateWeight.getText().toString());
                float targetWeight = Float.parseFloat(etUpdateTargetWeight.getText().toString());

                boolean isUpdated = userData.updateWeightRecord(recordId, date, weight, targetWeight);
                if (isUpdated) {
                    Toast.makeText(MainActivity.this, "Record updated", Toast.LENGTH_SHORT).show();
                    loadWeightRecords();
                } else {
                    Toast.makeText(MainActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteWeightRecord(int recordId) {
        boolean isDeleted = userData.deleteWeightRecord(recordId);
        if (isDeleted) {
            Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
            loadWeightRecords();
        } else {
            Toast.makeText(MainActivity.this, "Failed to delete record", Toast.LENGTH_SHORT).show();
        }
    }
}