package com.example.myapplication_dc;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class WeightTrackingActivity extends AppCompatActivity {

    private EditText etDate, etWeight, etTargetWeight;
    private Button btnAdd, btnView;
    private ListView lvWeightRecords;

    private DatabaseHelper databaseHelper;
    private ArrayList<String> weightRecords;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        // Initialize UI elements
        etDate = findViewById(R.id.et_date);
        etWeight = findViewById(R.id.et_weight);
        etTargetWeight = findViewById(R.id.et_target_weight);
        btnAdd = findViewById(R.id.btn_add);
        btnView = findViewById(R.id.btn_view);
        lvWeightRecords = findViewById(R.id.lv_weight_records);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize the weight records ArrayList and adapter
        weightRecords = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightRecords);
        lvWeightRecords.setAdapter(adapter);

        // Add record to the database
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightRecord();
            }
        });

        // View all records from the database
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWeightRecords();
            }
        });

        // Handle ListView item click for update and delete
        lvWeightRecords.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String record = weightRecords.get(position);
                int recordId = Integer.parseInt(record.split(",")[0].split(":")[1].trim());
                showUpdateDeleteDialog(recordId);
            }
        });
    }

    private void addWeightRecord() {
        String date = etDate.getText().toString();
        float weight = Float.parseFloat(etWeight.getText().toString());
        float targetWeight = Float.parseFloat(etTargetWeight.getText().toString());

        boolean isInserted = databaseHelper.addWeightRecord(date, weight, targetWeight);
        if (isInserted) {
            Toast.makeText(WeightTrackingActivity.this, "Record added successfully", Toast.LENGTH_SHORT).show();
            loadWeightRecords();
        } else {
            Toast.makeText(WeightTrackingActivity.this, "Failed to add record", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadWeightRecords() {
        Cursor cursor = databaseHelper.getAllRecords();
        weightRecords.clear();

        if (cursor.getCount() == 0) {
            Toast.makeText(WeightTrackingActivity.this, "No records found", Toast.LENGTH_SHORT).show();
            return;
        }

        while (cursor.moveToNext()) {
            String record = "ID: " + cursor.getInt(0) +
                    ", Date: " + cursor.getString(1) +
                    ", Weight: " + cursor.getFloat(2) +
                    ", Target Weight: " + cursor.getFloat(3);
            weightRecords.add(record);
        }

        adapter.notifyDataSetChanged();
    }

    private void showUpdateDeleteDialog(final int recordId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(WeightTrackingActivity.this);
        builder.setTitle("Choose an option");
        builder.setItems(new CharSequence[]{"Update", "Delete"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    showUpdateDialog(recordId);
                } else {
                    deleteWeightRecord(recordId);
                }
            }
        });
        builder.show();
    }

    private void showUpdateDialog(final int recordId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(WeightTrackingActivity.this);
        builder.setTitle("Update Record");

        View updateView = getLayoutInflater().inflate(R.layout.dialog_update_weight, null);
        final EditText etUpdateDate = updateView.findViewById(R.id.et_update_date);
        final EditText etUpdateWeight = updateView.findViewById(R.id.et_update_weight);
        final EditText etUpdateTargetWeight = updateView.findViewById(R.id.et_update_target_weight);

        builder.setView(updateView);
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String date = etUpdateDate.getText().toString();
                float weight = Float.parseFloat(etUpdateWeight.getText().toString());
                float targetWeight = Float.parseFloat(etUpdateTargetWeight.getText().toString());

                boolean isUpdated = databaseHelper.updateWeightRecord(recordId, date, weight, targetWeight);
                if (isUpdated) {
                    Toast.makeText(WeightTrackingActivity.this, "Record updated", Toast.LENGTH_SHORT).show();
                    loadWeightRecords();
                } else {
                    Toast.makeText(WeightTrackingActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteWeightRecord(int recordId) {
        boolean isDeleted = databaseHelper.deleteWeightRecord(recordId);
        if (isDeleted) {
            Toast.makeText(WeightTrackingActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
            loadWeightRecords();
        } else {
            Toast.makeText(WeightTrackingActivity.this, "Failed to delete record", Toast.LENGTH_SHORT).show();
        }
    }
}