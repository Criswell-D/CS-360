package com.example.myapplication_dc;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserDao {
    @Insert
    long addUser(User user); // Inserts a user and returns the newly generated user ID

    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    User validateUser(String username, String password); // Validates user login

    @Query("SELECT * FROM users")
    List<User> getAllUsers(); // Retrieves all users
}